import { world } from "mojang-minecraft";

world.events.entityCreate.subscribe((data) => {
    if(data.entity.id == "vl:dna_sequencer")
        data.entity.nameTag = `dna_sequencer`;
})
