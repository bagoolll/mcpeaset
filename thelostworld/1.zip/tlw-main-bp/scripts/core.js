import "./incubator/egg_incubator.js";
import './incubator/dna.js'