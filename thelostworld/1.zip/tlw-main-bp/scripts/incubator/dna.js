//bridge-file-version: #0
import { world, ItemStack, Container, system } from "@minecraft/server";

const Dna = [
    'vl:brachi_dna',
    'vl:carno_dna',
    'vl:compy_dna',
    'vl:dilo_dna',
    'vl:frog_dna',
    'vl:galli_dna',
    'vl:giga_dna',
    'vl:irex_dna',
    'vl:mosa_dna',
    'vl:pachy_dna',
    'vl:spino_dna',
    'vl:tylo_dna'
]

system.runInterval(() => {

    for (const entity of world.getDimension('overworld').getEntities({ 'families': ["dna_sequencer"] })) {

        if (!entity) return;
        if (!entity.nameTag || entity.nameTag != 'DNA Sequencer') entity.nameTag = 'DNA Sequencer'
        /**
         * @type Container
         */
        const inv = entity.getComponent('inventory').container

        let inputSlot = undefined;
        let outputSlot = undefined;

        const randomOutput = Dna[Math.floor(Math.random() * Dna.length)]

        for (let i = 0; i < 6; i += 2) {
            /**
             * @type ItemStack
             */
            const item = inv.getItem(i)
            if (item && item.typeId == 'vl:amber') { inputSlot = i; break };
        }

        for (let i = 1; i < 6; i += 2) {
            /**
             * @type ItemStack
             */
            const item = inv.getItem(i)
            if (!item || (item.typeId == randomOutput)) { outputSlot = i; break };
        }

        if (inputSlot == undefined || outputSlot == undefined) return;

        const input = inv.getItem(inputSlot)
        const output = inv.getItem(outputSlot)

        if (!input) return;

        if (!output || output.typeId == undefined) {
            inv.setItem(outputSlot, new ItemStack(randomOutput, 1))
            if (input.amount == 1) {
                inv.setItem(inputSlot);
            } else {
                input.amount -= 1
                inv.setItem(inputSlot, input)
            }
        } else {
            output.amount += 1;
            inv.setItem(outputSlot, output)
            if (input.amount == 1) {
                inv.setItem(inputSlot);
            } else {
                input.amount -= 1
                inv.setItem(inputSlot, input)
            }
        }

    }
}, 10)

world.afterEvents.blockPlace.subscribe(event => {

    const location = { x: event.block.location.x + 0.5, y: event.block.location.y, z: event.block.location.z + 0.5 }
    if (event.block.typeId == 'vl:dna_sequencer') event.dimension.spawnEntity('vl:dna_sequencer', location)

})

world.afterEvents.blockBreak.subscribe(event => {

    const location = { x: Math.floor(event.block.location.x), y: Math.floor(event.block.location.y + 1), z: Math.floor(event.block.location.z) }
    if (event.brokenBlockPermutation.type.id == 'vl:dna_sequencer') event.dimension.runCommandAsync(`execute positioned ${location.x} ${location.y} ${location.z} run kill @e[type=vl:dna_sequencer,c=1,r=2]`)

})