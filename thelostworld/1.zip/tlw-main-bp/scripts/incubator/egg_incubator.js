//bridge-file-version: #0
import { world, ItemStack, Container, system } from "@minecraft/server";

const Eggs = new Map()
    .set("vl:carnotaurus_egg", "vl:hatched_carnotaurus_egg")
    .set("vl:compsognathus_egg", "vl:hatched_compsognathus_egg")
    .set("vl:indoraptor_egg", "vl:hatched_indoraptor_egg")
    .set("vl:velociraptor_egg", "vl:hatched_velociraptor_egg")
    .set("vl:tyrannosaus_egg", "vl:hatched_tyrannosaus_egg")
    .set("vl:tylosaurus_egg", "vl:hatched_tylosaurus_egg")
    .set("vl:triceratops_egg", "vl:hatched_triceratops_egg")
    .set("vl:spinosarus_egg", "vl:hatched_spinosarus_egg")
    .set("vl:pachycephalosaurus_egg", "vl:hatched_pachycephalosaurus_egg")
    .set("vl:mosasurus_egg", "vl:hatched_mosasurus_egg")
    .set("vl:indominusrex_egg", "vl:hatched_indominusrex_egg")
    .set("vl:giganotosaurus_egg", "vl:hatched_giganotosaurus_egg")
    .set("vl:gallimimus_egg", "vl:hatched_gallimimus_egg")
    .set("vl:dilophosaurus_egg", "vl:hatched_dilophosaurus_egg")
    .set("vl:brachiosaurus_egg", "vl:hatched_brachiosaurus_egg")

let tick0 = 0;
let tick1 = 0;
let tick2 = 0;
let tick3 = 0;

let time = 50;

system.runInterval(() => {

    for (const entity of world.getDimension('overworld').getEntities({ 'families': ["egg_incubator"] })) {

        if (!entity) return;

        /**
         * @type { Container }
         */
        const inv = entity.getComponent('inventory').container
        let inputs = [];

        if (!entity.nameTag || entity.nameTag != 'Egg Incubator') entity.nameTag = 'Egg Incubator'

        for (let i = 0; i < 4; i++) {
            /**
             * @type ItemStack
             */
            const item = inv.getItem(i)
            if (!item || item.typeId == 'minecraft:air') { inputs.push('No Item') } else { inputs.push(item.typeId) }
        }

        inputs.forEach(id => {

            const index = inputs.indexOf(id);
            const res = index + 4
            const currentResult = inv.getItem(res);

            if (Eggs.has(id) && (!currentResult || currentResult.typeId == Eggs.get(id))) {

                if (index == 0) {

                    if (tick0 == 0) {
                        tick0 = system.currentTick
                    } else if (system.currentTick >= (tick0 + time)) {

                        if (currentResult && currentResult.typeId == Eggs.get(id)) {
                            const result = inv.getItem(res)
                            result.amount += 1
                            inv.setItem(res, result)
                        } else {
                            const result = new ItemStack(Eggs.get(id), 1)
                            inv.setItem(res, result)
                        }

                        tick0 = 0

                        if (inv.getItem(index).amount > 1) {
                            const result = inv.getItem(index)
                            result.amount += -1
                            inv.setItem(index, result)
                        } else {
                            inv.setItem(index)
                        }

                    }

                } else if (index == 1) {

                    if (tick1 == 0) {
                        tick1 = system.currentTick
                    } else if (system.currentTick >= (tick1 + time)) {

                        if (currentResult && currentResult.typeId == Eggs.get(id)) {
                            const result = inv.getItem(res)
                            result.amount += 1
                            inv.setItem(res, result)
                        } else {
                            const result = new ItemStack(Eggs.get(id), 1)
                            inv.setItem(res, result)
                        }

                        tick1 = 0

                        if (inv.getItem(index).amount > 1) {
                            const result = inv.getItem(index)
                            result.amount += -1
                            inv.setItem(index, result)
                        } else {
                            inv.setItem(index)
                        }

                    }

                } else if (index == 2) {

                    if (tick2 == 0) {
                        tick2 = system.currentTick
                    } else if (system.currentTick >= (tick2 + time)) {

                        if (currentResult && currentResult.typeId == Eggs.get(id)) {
                            const result = inv.getItem(res)
                            result.amount += 1
                            inv.setItem(res, result)
                        } else {
                            const result = new ItemStack(Eggs.get(id), 1)
                            inv.setItem(res, result)
                        }

                        tick2 = 0

                        if (inv.getItem(index).amount > 1) {
                            const result = inv.getItem(index)
                            result.amount += -1
                            inv.setItem(index, result)
                        } else {
                            inv.setItem(index)
                        }

                    }

                } else if (index == 3) {

                    if (tick3 == 0) {
                        tick3 = system.currentTick
                    } else if (system.currentTick >= (tick3 + time)) {

                        if (currentResult && currentResult.typeId == Eggs.get(id)) {
                            const result = inv.getItem(res)
                            result.amount += 1
                            inv.setItem(res, result)
                        } else {
                            const result = new ItemStack(Eggs.get(id), 1)
                            inv.setItem(res, result)
                        }

                        tick3 = 0

                        if (inv.getItem(index).amount > 1) {
                            const result = inv.getItem(index)
                            result.amount += -1
                            inv.setItem(index, result)
                        } else {
                            inv.setItem(index)
                        }

                    }

                }

            } else {

                switch (index) {
                    case 0:
                        tick0 = 0
                        break;
                    case 1:
                        tick1 = 0
                        break;
                    case 2:
                        tick2 = 0
                        break;
                    case 3:
                        tick3 = 0
                        break;
                    default:
                        break;
                }
            }

        })
    }
}, 0)

world.afterEvents.blockPlace.subscribe(event => {

    const location = { x: event.block.location.x + 0.5, y: event.block.location.y + 1, z: event.block.location.z + 0.5}
    if (event.block.typeId == 'vl:eggs_incubator') event.dimension.spawnEntity('vl:egg_incubator', location) 

})

// world.afterEvents.blockBreak.subscribe(event => {

//     const location = { x: Math.floor(event.block.location.x)  0.5, y: Math.floor(event.block.location.y + 1), z: Math.floor(event.block.location.z) + 0.5 }
//     if (event.brokenBlockPermutation.type.id == 'vl:eggs_incubator') event.dimension.runCommandAsync(`execute positioned ${location.x} ${location.y} ${location.z} run kill @e[type=vl:egg_incubator,c=1,r=2]`)

// })